package com.example.gd8_c_0639.models

class Mahasiswa (var nama:String, var npm:String, var fakultas:String, var prodi:String){
    var id: Long? = null
}